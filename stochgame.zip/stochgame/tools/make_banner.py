"""
Generates assets/banner.gif, assets/banner.png, assets/divider.gif.
numpy + stdlib only: own bitmap font, own GIF (LZW) and PNG encoders.
The orbiting comets are real replicator-dynamics trajectories from stochgame.py.

    python tools/make_banner.py
"""
import os
import struct
import sys
import zlib

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import stochgame as sg  # noqa: E402

W, H, F = 720, 200, 48          # size, frames per loop
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets")

# ----------------------------------------------------------------- 5x7 font --
_G = {
    "A": ".###.|#...#|#...#|#####|#...#|#...#|#...#", "C": ".###.|#...#|#....|#....|#....|#...#|.###.",
    "D": "####.|#...#|#...#|#...#|#...#|#...#|####.", "E": "#####|#....|#....|####.|#....|#....|#####",
    "F": "#####|#....|#....|####.|#....|#....|#....", "G": ".###.|#...#|#....|#.###|#...#|#...#|.###.",
    "H": "#...#|#...#|#...#|#####|#...#|#...#|#...#", "I": ".###.|..#..|..#..|..#..|..#..|..#..|.###.",
    "L": "#....|#....|#....|#....|#....|#....|#####", "M": "#...#|##.##|#.#.#|#.#.#|#...#|#...#|#...#",
    "N": "#...#|##..#|#.#.#|#..##|#...#|#...#|#...#", "O": ".###.|#...#|#...#|#...#|#...#|#...#|.###.",
    "P": "####.|#...#|#...#|####.|#....|#....|#....", "R": "####.|#...#|#...#|####.|#.#..|#..#.|#...#",
    "S": ".####|#....|#....|.###.|....#|....#|####.", "T": "#####|..#..|..#..|..#..|..#..|..#..|..#..",
    "U": "#...#|#...#|#...#|#...#|#...#|#...#|.###.", "Y": "#...#|#...#|.#.#.|..#..|..#..|..#..|..#..",
    "Z": "#####|....#|...#.|..#..|.#...|#....|#####", "-": ".....|.....|.....|#####|.....|.....|.....",
    " ": ".....|.....|.....|.....|.....|.....|.....", "_": ".....|.....|.....|.....|.....|.....|#####",
}
FONT = {k: np.array([[c == "#" for c in row] for row in v.split("|")], float) for k, v in _G.items()}


def text_mask(txt, scale, h=H, w=W, x=0, y=0):
    m = np.zeros((h, w))
    cx = x
    for ch in txt:
        g = np.kron(FONT[ch], np.ones((scale, scale)))
        gh, gw = g.shape
        m[y:y + gh, cx:cx + gw] = np.maximum(m[y:y + gh, cx:cx + gw], g)
        cx += 6 * scale
    return m


# ------------------------------------------------------------------ drawing --
def blur(img, sigma):
    r = int(sigma * 3)
    k = np.exp(-0.5 * (np.arange(-r, r + 1) / sigma) ** 2)
    k /= k.sum()
    for ax in (0, 1):
        pad = [(0, 0)] * img.ndim
        pad[ax] = (r, r)
        p = np.pad(img, pad)
        out = np.zeros_like(img)
        for i, wgt in enumerate(k):
            out += wgt * np.take(p, np.arange(i, i + img.shape[ax]), axis=ax)
        img = out
    return img


def splat(cv, x, y, col, sigma, amp):
    r = int(np.ceil(sigma * 3))
    x0, y0 = int(round(x)), int(round(y))
    xs, ys = np.arange(max(x0 - r, 0), min(x0 + r + 1, cv.shape[1])), np.arange(max(y0 - r, 0), min(y0 + r + 1, cv.shape[0]))
    if xs.size == 0 or ys.size == 0:
        return
    g = np.exp(-((xs[None, :] - x) ** 2 + (ys[:, None] - y) ** 2) / (2 * sigma ** 2))
    cv[ys[0]:ys[-1] + 1, xs[0]:xs[-1] + 1] += amp * g[..., None] * np.asarray(col, float)


def line(cv, p, q, col, amp, sigma=0.8):
    n = int(np.hypot(*(np.subtract(q, p))) * 1.2)
    for t in np.linspace(0, 1, n):
        splat(cv, p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t, col, sigma, amp)


CYAN, MAGENTA, GOLD, MINT, VIOLET = (0.31, 0.90, 1.0), (1.0, 0.39, 0.78), (1.0, 0.82, 0.35), (0.5, 1.0, 0.63), (0.67, 0.55, 1.0)


# -------------------------------------------------------------- scene setup --
def build_scene():
    yy, xx = np.mgrid[0:H, 0:W]
    bg = np.stack([0.025 + 0.02 * yy / H, 0.035 + 0.03 * yy / H, 0.08 + 0.06 * yy / H], -1)
    vig = 1 - 0.45 * (((xx - W / 2) / (W / 2)) ** 2 + ((yy - H / 2) / (H / 2)) ** 2) / 2
    bg = bg * vig[..., None]

    # title
    tm = text_mask("STOCHGAME", 7, x=30, y=34)
    grad = np.stack([np.interp(xx, [30, 400], [a, b]) for a, b in zip(CYAN, MAGENTA)], -1)
    glow = blur(tm, 7)[..., None] * grad
    sub1 = text_mask("STOCHASTIC GAMES FOR AUTONOMOUS AGENTS", 2, x=32, y=108)
    sub2 = text_mask("NUMPY ONLY - ZERO DEPENDENCIES", 2, x=32, y=134)
    sub2_end = 32 + 6 * 2 * len("NUMPY ONLY - ZERO DEPENDENCIES")
    cursor = text_mask("_", 2, x=sub2_end, y=134)
    rule = np.zeros((H, W))
    rule[98:100, 32:400] = 1

    # orbits of replicator dynamics on the RPS simplex (real engine output)
    cx, cy, R = 592, 112, 82
    ang = np.deg2rad([-90, 30, 150])
    V = np.stack([cx + R * np.cos(ang), cy + R * np.sin(ang)], 1)
    static = np.zeros((H, W, 3))
    for i in range(3):
        line(static, V[i], V[(i + 1) % 3], (0.45, 0.55, 0.8), 0.22)
    orbits = []
    for d, col in zip([0.07, 0.15, 0.23, 0.31, 0.38], [CYAN, MAGENTA, GOLD, MINT, VIOLET]):
        x0 = np.array([1 / 3 + d, 1 / 3 - d / 2, 1 / 3 - d / 2])
        tr = sg.replicator(sg.rps_matrix(), x0, steps=4000, dt=0.02)
        dist = np.linalg.norm(tr - x0, axis=1)
        mins = [i for i in range(60, len(dist) - 1) if dist[i] < dist[i - 1] and dist[i] <= dist[i + 1] and dist[i] < 0.03 * dist.max()]
        orb = tr[:mins[0] + 1] @ V
        orbits.append((orb, col))
        for p in orb[::2]:
            splat(static, p[0], p[1], col, 0.7, 0.16)
    for lab, p in zip("RPS", V):
        off = np.array(p) - [cx, cy]
        off = off / np.linalg.norm(off) * 15
        tx = int(np.clip(p[0] + off[0] - 5, 0, W - 12))
        ty = int(np.clip(p[1] + off[1] - 7, 0, H - 16))
        static += text_mask(lab, 2, x=tx, y=ty)[..., None] * np.array([0.7, 0.78, 0.95])
    return dict(bg=bg, tm=tm, grad=grad, glow=glow, sub1=sub1, sub2=sub2, cursor=cursor, rule=rule,
                static=static, orbits=orbits, c=(cx, cy), xx=xx, yy=yy)


def comet(cv, orb, col, u, k=16, step=0.7 / F):
    n = len(orb)
    for j in range(k):
        uu = (u - j * step) % 1.0 * (n - 1)
        i = int(uu)
        p = orb[i] + (orb[min(i + 1, n - 1)] - orb[i]) * (uu - i)
        f = 1 - j / k
        splat(cv, p[0], p[1], col, 1.0 + 2.2 * f, 0.9 * f ** 1.6)
        if j == 0:
            splat(cv, p[0], p[1], (1, 1, 1), 1.3, 0.9)
            splat(cv, p[0], p[1], col, 7, 0.35)


def render(sc, t):
    ph = t / F
    cv = sc["bg"].copy()
    cv[10::20, (int(20 * ph) % 20)::20] += 0.10                        # drifting dot grid
    cv += sc["static"]
    pulse = 0.65 + 0.35 * np.sin(2 * np.pi * ph)
    cv += sc["glow"] * (0.9 * pulse)
    band = np.exp(-(((sc["xx"] - (-60 + 520 * ph)) + 0.7 * (sc["yy"] - 34)) / 22.0) ** 2)  # shimmer sweep
    cv += sc["tm"][..., None] * (sc["grad"] * 1.0 + 0.55 * band[..., None])
    cv += sc["rule"][..., None] * sc["grad"] * 0.55
    cv += sc["sub1"][..., None] * np.array([0.58, 0.66, 0.82])
    cv += sc["sub2"][..., None] * np.array([0.40, 0.88, 0.75])
    if (t // 6) % 2 == 0:
        cv += sc["cursor"][..., None] * np.array([0.9, 1.0, 0.95])
    cx, cy = sc["c"]
    splat(cv, cx, cy, (1, 1, 1), 2.0 + 0.6 * np.sin(2 * np.pi * ph), 0.7)      # Nash point
    splat(cv, cx, cy, CYAN, 9, 0.18 + 0.1 * np.sin(2 * np.pi * ph))
    for orb, col in sc["orbits"]:
        comet(cv, orb, col, ph)
    return np.clip(cv, 0, 1)


# --------------------------------------------------------------- quantising --
LV = (6, 7, 6)
GAMMA = 1.6
_BAYER = (np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) + 0.5) / 16 - 0.5
TRANSPARENT = 252


def palette():
    pal = np.zeros((256, 3), np.uint8)
    i = 0
    for r in range(LV[0]):
        for g in range(LV[1]):
            for b in range(LV[2]):
                pal[i] = [255 * (r / (LV[0] - 1)) ** GAMMA, 255 * (g / (LV[1] - 1)) ** GAMMA, 255 * (b / (LV[2] - 1)) ** GAMMA]
                i += 1
    return pal


def quantize(img):
    h, w, _ = img.shape
    d = np.tile(_BAYER, (h // 4 + 1, w // 4 + 1))[:h, :w]
    q = []
    for c in range(3):
        v = img[..., c] ** (1 / GAMMA) * (LV[c] - 1) + d
        q.append(np.clip(np.rint(v), 0, LV[c] - 1).astype(np.int32))
    return ((q[0] * LV[1] + q[1]) * LV[2] + q[2]).astype(np.uint8)


# ----------------------------------------------------------------- encoders --
def lzw(data, mcs=8):
    clear, eoi = 1 << mcs, (1 << mcs) + 1
    size, nxt, table = mcs + 1, eoi + 1, {}
    out, acc, nb = bytearray(), clear, mcs + 1
    prefix = data[0]
    for byte in data[1:]:
        key = (prefix << 8) | byte
        c = table.get(key)
        if c is not None:
            prefix = c
            continue
        acc |= prefix << nb
        nb += size
        while nb >= 8:
            out.append(acc & 255)
            acc >>= 8
            nb -= 8
        if nxt < 4096:
            table[key] = nxt
            nxt += 1
            if nxt > (1 << size):
                size += 1
        else:
            acc |= clear << nb
            nb += size
            while nb >= 8:
                out.append(acc & 255)
                acc >>= 8
                nb -= 8
            table.clear()
            size, nxt = mcs + 1, eoi + 1
        prefix = byte
    acc |= prefix << nb
    nb += size
    while nb >= 8:
        out.append(acc & 255)
        acc >>= 8
        nb -= 8
    if nxt < 4096:
        nxt += 1
        if nxt > (1 << size):
            size += 1
    acc |= eoi << nb
    nb += size
    while nb > 0:
        out.append(acc & 255)
        acc >>= 8
        nb -= 8
    return bytes(out)


def write_gif(path, frames, pal, delay=5):
    """frames: list of (H,W) uint8 index arrays. Unchanged pixels become transparent."""
    h, w = frames[0].shape
    b = bytearray(b"GIF89a" + struct.pack("<HHBBB", w, h, 0xF7, 0, 0) + pal.tobytes())
    b += b"\x21\xff\x0bNETSCAPE2.0\x03\x01\x00\x00\x00"
    prev = None
    for fr in frames:
        img = fr
        if prev is not None:
            img = np.where(fr == prev, TRANSPARENT, fr).astype(np.uint8)
        prev = fr
        b += b"\x21\xf9\x04" + bytes([(1 << 2) | 1]) + struct.pack("<H", delay) + bytes([TRANSPARENT, 0])
        b += b"\x2c" + struct.pack("<HHHHB", 0, 0, w, h, 0) + b"\x08"
        data = lzw(img.tobytes())
        for i in range(0, len(data), 255):
            chunk = data[i:i + 255]
            b += bytes([len(chunk)]) + chunk
        b += b"\x00"
    b += b"\x3b"
    open(path, "wb").write(b)


def write_png(path, rgb):
    h, w, _ = rgb.shape
    raw = b"".join(b"\x00" + rgb[y].tobytes() for y in range(h))

    def chunk(tag, d):
        c = struct.pack(">I", len(d)) + tag + d
        return c + struct.pack(">I", zlib.crc32(tag + d) & 0xFFFFFFFF)

    open(path, "wb").write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
                           + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


# ------------------------------------------------------------------ divider --
def divider_frames(w=720, h=8, n=48):
    xs = np.arange(w)
    base = np.array([0.03, 0.045, 0.1])
    col = np.stack([np.interp(xs, [0, w], [a, b]) for a, b in zip(CYAN, MAGENTA)], -1)
    prof = np.exp(-(((np.arange(h) - (h - 1) / 2) / 1.6) ** 2))[:, None]
    out = []
    for t in range(n):
        inten = np.zeros(w)
        for k in range(3):
            p = (t * w / n + k * w / 3) % w
            dx = (xs - p + w / 2) % w - w / 2
            inten += np.exp(-(dx / 36.0) ** 2) + 0.35 * np.exp(-(dx / 120.0) ** 2)
        img = base + prof[..., None] * col[None] * (0.18 + 0.82 * np.clip(inten, 0, 1))[None, :, None]
        out.append(np.clip(img, 0, 1))
    return out


def main():
    os.makedirs(OUT, exist_ok=True)
    pal = palette()
    sc = build_scene()
    frames = [render(sc, t) for t in range(F)]
    write_gif(os.path.join(OUT, "banner.gif"), [quantize(f) for f in frames], pal, delay=5)
    write_png(os.path.join(OUT, "banner.png"), (frames[int(F * 0.3)] * 255).astype(np.uint8))
    write_gif(os.path.join(OUT, "divider.gif"), [quantize(f) for f in divider_frames()], pal, delay=5)
    for f in ("banner.gif", "banner.png", "divider.gif"):
        print(f"assets/{f}: {os.path.getsize(os.path.join(OUT, f)) / 1024:.0f} KB")


if __name__ == "__main__":
    main()
